
import './App.css';

  
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ProductsList from './components/ProductList';
import ProductDetails from './components/ProductDetails';

const App = () => {
  const [cartItems, setCartItems] = useState([]);

  const handleAddToCart = (product) => {
    setCartItems([...cartItems, product]);
  };

  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <ProductsList onProductClick={(productId) => { /* Handle navigation to Product Details Page */ }} />
        </Route>
        <Route path="/product/:id">
          <ProductDetails onAddToCart={handleAddToCart} />
        </Route>
      </Switch>
    </Router>
  );
};

export default App;