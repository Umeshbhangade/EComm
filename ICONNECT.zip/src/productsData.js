
const productsData = [
    {
      id: 1,
      name: 'Product 1',
      price: 10.99,
      quantity: 20,
      imageUrl: 'imgs/product1.jpg',
    },
    {
       id: 2,
       name: 'Product 2',
       price: 20.99,
       quantity: 10,
       imageUrl: 'imgs/product1.jpg',
    },
    {
       id: 3,
       name: 'Product 3',
       price: 30.99,
       quantity: 15,
       imageUrl: 'imgs/product3.jpg',
    },
    
  ];
  
  export default productsData;