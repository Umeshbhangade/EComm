import React from 'react';
import productsData from '../productsData';
import ProductCard from '../productCard';
const ProductsList = ({ onProductClick }) => {
  return (
    <div>
      <h2>Products List</h2>
      {productsData.map((product) => (
        <div key={product.id} onClick={() => onProductClick(product.id)}>
          <img src={product.imageUrl} alt={product.name} />
          <h3>{product.name}</h3>
          <p>Price: ${product.price}</p>
        </div>
      ))}
    </div>
    
  );
};

export default ProductsList;