import React from 'react';
import productsData from '../productsData';

const ProductDetails = ({ productId, onAddToCart }) => {
  const product = productsData.find((product) => product.id === productId);

  if (!product) {
    return <div>Product not found.</div>;
  }

  return (
    <div>
      <h2>Product Details</h2>
      <img src={product.imageUrl} alt={product.name} />
      <h3>{product.name}</h3>
      <p>Price: ${product.price}</p>
      <p>Quantity: {product.quantity}</p>
      <button onClick={() => onAddToCart(product)}>Add to Cart</button>
    </div>
  );
};

export default ProductDetails;
